
  # Kawiarnia System Frontend

  This is a code bundle for Kawiarnia System Frontend. The original project is available at https://www.figma.com/design/A5BByUhPnAfJ8DpVeh96pa/Kawiarnia-System-Frontend.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  